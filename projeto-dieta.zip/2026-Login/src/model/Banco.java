
package model;

public class Banco {
    public static String[] usuarios = new String[10];
    public static String[] senhas = new String[10];
    
    public static int total = 0;

public static void cadastrar(String usuario, String senha) {

        usuarios[total] = usuario;
        senhas[total] = senha;
        total++;
}
public static boolean fazerLogin(String usuario, String senha) {

        for(int i = 0; i < total; i++) {

            if(usuarios[i].equals(usuario)
                    && senhas[i].equals(senha)) {

                return true;
            }
        }

        return false;
    }
}
